/*
 * DIO.h
 *
 *  Created on: Oct 25, 2019
 *      Author: Mohamed Samy
 */

#ifndef DIO_H_
#define DIO_H_

#include "stm32f10x_gpio.h"

#define D_PORT(_N)		_N##_Port
#define D_PIN(_N)		_N##_Pin
#define GPIOx(_N)		((GPIO_TypeDef *)(GPIOA_BASE + (GPIOB_BASE-GPIOA_BASE)*(_N)))

#define A0_Port 		0
#define A1_Port 		0
#define A2_Port 		0
#define A3_Port 		0
#define A4_Port 		0
#define A5_Port 		0
#define A6_Port 		0
#define A7_Port 		0
#define A8_Port 		0
#define A9_Port 		0
#define A10_Port 		0
#define A11_Port 		0
#define A12_Port 		0
#define A15_Port 		0

#define B0_Port 		1
#define B1_Port 		1
#define B3_Port 		1
#define B4_Port 		1
#define B5_Port 		1
#define B6_Port 		1
#define B7_Port 		1
#define B8_Port 		1
#define B9_Port 		1
#define B10_Port 		1
#define B11_Port 		1
#define B12_Port 		1
#define B13_Port 		1
#define B14_Port 		1
#define B15_Port 		1

#define C13_Port 		2
#define C14_Port 		2
#define C15_Port 		2

#define A0_Pin	 		0
#define A1_Pin	 		1
#define A2_Pin	 		2
#define A3_Pin	 		3
#define A4_Pin	 		4
#define A5_Pin	 		5
#define A6_Pin	 		6
#define A7_Pin	 		7
#define A8_Pin	 		8
#define A9_Pin	 		9
#define A10_Pin 		10
#define A11_Pin 		11
#define A12_Pin 		12
#define A15_Pin 		15

#define B0_Pin	 		0
#define B1_Pin	 		1
#define B3_Pin	 		3
#define B4_Pin	 		4
#define B5_Pin	 		5
#define B6_Pin	 		6
#define B7_Pin	 		7
#define B8_Pin	 		8
#define B9_Pin	 		9
#define B10_Pin 		10
#define B11_Pin 		11
#define B12_Pin 		12
#define B13_Pin 		13
#define B14_Pin 		14
#define B15_Pin 		15

#define C13_Pin 		13
#define C14_Pin 		14
#define C15_Pin 		15

typedef enum
{
	pinMode_IN_FLOATING 	= GPIO_Mode_IN_FLOATING,	//floating
	pinMode_IN_IPD 			= GPIO_Mode_IPD,			//internal pull up
	pinMode_IN_IPU			= GPIO_Mode_IPU,			//internal pull down
	pinMode_Out_OD			= GPIO_Mode_Out_OD,			//open drain output
	pinMode_Out_PP			= GPIO_Mode_Out_PP			//open push-pull
}pinMode_t;

typedef enum
{
	LOW 	= 0,
	HIGH 	= 1
}val_t;

#define DIO_INIT(pin, pinMode) 		DIO_init(D_PORT(pin), D_PIN(pin), pinMode)
#define DIO_SETVAL(pin, val) 		DIO_setVal(D_PORT(pin), D_PIN(pin), val)
#define DIO_set(pin)				GPIO_SetBits(GPIOx(D_PORT(pin)), (1 << D_PIN(pin)))
#define DIO_reset(pin)				GPIO_ResetBits(GPIOx(D_PORT(pin)), (1 << D_PIN(pin)))
#define DIO_read(pin)				GPIO_ReadInputDataBit(GPIOx(D_PORT(pin)), (1 << D_PIN(pin)))

void DIO_init(uint8_t port, uint8_t pin, pinMode_t mode);
void DIO_setVal(uint8_t port, uint8_t pin, uint8_t val);

#endif /* DIO_H_ */
