#include "BSW.h"

int main()
{
	BSW_init();

	while(1)
	{
		
	}
}

