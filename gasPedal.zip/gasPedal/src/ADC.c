/*
 * ADC.c
 *
 *  Created on: Nov 27, 2019
 *      Author: Mohamed Aboelfottoh
 */

#include "DIO.h"
#include "ADC.h"

#define Length(arr)					sizeof(arr)/sizeof(arr[0])

static volatile uint16_t ADCBuffer[Length(ADCChannels)];

void ADC_init()
{
	ADC_InitTypeDef ADC_InitStructure;
	DMA_InitTypeDef DMA_InitStructure;
	uint8_t i;

	RCC_ADCCLKConfig(RCC_PCLK2_Div6);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC1 | RCC_APB2Periph_AFIO, ENABLE);
	RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA1, ENABLE);

	DMA_InitStructure.DMA_BufferSize 			= Length(ADCChannels);
	DMA_InitStructure.DMA_DIR 					= DMA_DIR_PeripheralSRC;
	DMA_InitStructure.DMA_M2M 					= DMA_M2M_Disable;
	DMA_InitStructure.DMA_MemoryBaseAddr 		= (uint32_t)ADCBuffer;
	DMA_InitStructure.DMA_MemoryDataSize 		= DMA_MemoryDataSize_HalfWord;
	DMA_InitStructure.DMA_MemoryInc 			= DMA_MemoryInc_Enable;
	DMA_InitStructure.DMA_Mode 					= DMA_Mode_Circular;
	DMA_InitStructure.DMA_PeripheralBaseAddr 	= (uint32_t)&ADC1->DR;
	DMA_InitStructure.DMA_PeripheralDataSize 	= DMA_PeripheralDataSize_HalfWord;
	DMA_InitStructure.DMA_PeripheralInc 		= DMA_PeripheralInc_Disable;
	DMA_InitStructure.DMA_Priority 				= DMA_Priority_High;
	DMA_Init(DMA1_Channel1, &DMA_InitStructure);
	DMA_Cmd(DMA1_Channel1 , ENABLE) ;

	ADC_InitStructure.ADC_ContinuousConvMode 	= CONTINUOUS_MODE_ENABLE;
	ADC_InitStructure.ADC_ExternalTrigConv 		= ADC_ExternalTrigConv_;

	ADC_InitStructure.ADC_DataAlign 			= ADC_DataAlign_Right;
	ADC_InitStructure.ADC_Mode 					= ADC_Mode_Independent;
	ADC_InitStructure.ADC_NbrOfChannel 			= Length(ADCChannels);
	ADC_InitStructure.ADC_ScanConvMode 			= ENABLE;
	ADC_Init(ADC1, &ADC_InitStructure);

	for(i = 0; i < Length(ADCChannels); i++)
	{
		DIO_init((uint8_t)(ADCChannels[i]/8), (uint8_t)(ADCChannels[i]%8), GPIO_Mode_AIN);
		ADC_RegularChannelConfig(ADC1, ADCChannels[i], i+1, ADC_SampleTime_7Cycles5);
	}

	ADC_Cmd(ADC1 , ENABLE);
	ADC_DMACmd(ADC1 , ENABLE);
	ADC_ResetCalibration(ADC1);

	while(ADC_GetResetCalibrationStatus(ADC1));
	ADC_StartCalibration(ADC1);

	while(ADC_GetCalibrationStatus(ADC1));
	ADC_SoftwareStartConvCmd(ADC1 , ENABLE);

#if (INTERRUPT_ENABLE == ENABLE)
	ADC_ITConfig(ADC1, ADC_IT_EOC, ENABLE);

	NVIC_InitTypeDef nvicStructure;
	nvicStructure.NVIC_IRQChannel = ADC1_2_IRQn;
	nvicStructure.NVIC_IRQChannelPreemptionPriority = 0;
	nvicStructure.NVIC_IRQChannelSubPriority = 2;
	nvicStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&nvicStructure);
#endif
}

uint16_t ADC_Read(uint8_t channel)
{
	return (channel < Length(ADCBuffer))?ADCBuffer[channel]:0;
}

void ADC_StartConv()
{
	ADC_SoftwareStartConvCmd(ADC1, ENABLE);
}
