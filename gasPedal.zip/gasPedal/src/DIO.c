/*
 * DIO.c
 *
 *  Created on: Oct 25, 2019
 *      Author: Mohamed Samy
 */

#include "DIO.h"

void DIO_init(uint8_t port, uint8_t pin, pinMode_t mode)
{
	GPIO_InitTypeDef GPIO_InitStructure = {(1 << pin), GPIO_Speed_50MHz, mode};

	// Enable GPIO Peripheral clock
	RCC_APB2PeriphClockCmd((RCC_APB2Periph_GPIOA << port), ENABLE);

	GPIO_Init(GPIOx(port), &GPIO_InitStructure);
}

void DIO_setVal(uint8_t port, uint8_t pin, uint8_t val)
{
	if (val)
		GPIO_SetBits(GPIOx(port), (1 << pin));
	else
		GPIO_ResetBits(GPIOx(port), (1 << pin));
}
