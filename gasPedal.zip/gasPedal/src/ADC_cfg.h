/*
 * ADC_cfg.h
 *
 *  Created on: Nov 9, 2019
 *      Author: Mohamed Samy
 */

#ifndef ADC_CFG_H_
#define ADC_CFG_H_

#include "stm32f10x_adc.h"

#define INTERRUPT_ENABLE			ENABLE
#define CONTINUOUS_MODE_ENABLE		DISABLE
#define ADC_ExternalTrigConv_		ADC_ExternalTrigConv_None

static volatile uint8_t ADCChannels[] = {ADC_Channel_8, ADC_Channel_9};

#endif /* ADC_CFG_H_ */
