/*
 * Tasks.h
 *
 *  Created on: Nov 27, 2019
 *      Author: Mohamed Samy
 */

#ifndef Tasks_H_
#define Tasks_H_

void Task_100us();

#endif /* Tasks_H_ */
