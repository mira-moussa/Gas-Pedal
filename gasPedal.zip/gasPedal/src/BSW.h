/*
 * BSW.h
 *
 *  Created on: Nov 27, 2019
 *      Author: Mohamed Samy
 */

#ifndef BSW_H_
#define BSW_H_

#include "ADC.h"
#include "DIO.h"
#include "USART.h"
#include "Timer.h"
#include "Tasks.h"

extern volatile uint8_t idleCntr;

void BSW_init();

#endif /* BSW_H_ */
