/*
 * File: pedal.h
 *
 * Code generated for Simulink model 'ASW'.
 *
 * Model version                  : 1.3
 * Simulink Coder version         : 8.6 (R2014a) 27-Dec-2013
 * C/C++ source code generated on : Sat Nov 30 10:00:15 2019
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: 32-bit Generic
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_pedal_h_
#define RTW_HEADER_pedal_h_
#include <math.h>
#ifndef ASW_COMMON_INCLUDES_
# define ASW_COMMON_INCLUDES_
#include "rtwtypes.h"
#endif                                 /* ASW_COMMON_INCLUDES_ */

#include "ASW_types.h"

/* Block states (auto storage) for system '<Root>/pedal' */
typedef struct {
  uint8_T is_active_c3_ASW;            /* '<S4>/StateMachine' */
  uint8_T is_c3_ASW;                   /* '<S4>/StateMachine' */
} DW_pedal_T;

/* Extern declarations of internal data for system '<Root>/pedal' */
extern DW_pedal_T pedal_DW;
extern void pedal_initialize(void);
extern void ASW_Sensor1Fault(real32_T rtu_In1, real32_T *rty_Out1);
extern void pedal_Init(void);
extern void pedal_Start(void);
extern void pedal(uint16_T rtu_pedal1ADC, uint16_T rtu_pedal2ADC);

/* Exported data declaration */
extern real32_T pedalOut;

#endif                                 /* RTW_HEADER_pedal_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
