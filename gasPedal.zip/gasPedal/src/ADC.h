/*
 * ADC.h
 *
 *  Created on: Oct 26, 2019
 *      Author: Mohamed Samy
 */

#ifndef ADC_H_
#define ADC_H_

#include "ADC_cfg.h"

void ADC_init();
uint16_t ADC_Read(uint8_t channel);
void ADC_StartConv();

#endif /* ADC_H_ */
