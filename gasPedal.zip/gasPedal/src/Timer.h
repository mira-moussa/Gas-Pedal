/*
 * Timer.h
 *
 *  Created on: Nov 27, 2019
 *      Author: Mohamed Samy
 */

#include "stm32f10x_tim.h"

#ifndef TIMER_H_
#define TIMER_H_

void Timer_init();

#endif /* TIMER_H_ */
