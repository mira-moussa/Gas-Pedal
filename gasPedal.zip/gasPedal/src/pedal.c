/*
 * File: pedal.c
 *
 * Code generated for Simulink model 'ASW'.
 *
 * Model version                  : 1.3
 * Simulink Coder version         : 8.6 (R2014a) 27-Dec-2013
 * C/C++ source code generated on : Sat Nov 30 10:00:15 2019
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: 32-bit Generic
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "pedal.h"

/* Include model header file for global data */
#include "ASW.h"
#include "ASW_private.h"

/* Named constants for Chart: '<S4>/StateMachine' */
#define ASW_IN_COH                     ((uint8_T)1U)
#define ASW_IN_NO_ACTIVE_CHILD         ((uint8_T)0U)
#define ASW_IN_Running                 ((uint8_T)2U)
#define ASW_IN_Sensor1Fault            ((uint8_T)3U)
#define ASW_IN_Sensor2Fault            ((uint8_T)4U)

/* Exported data definition */
real32_T pedalOut;

/* Declare variables for internal data of system '<Root>/pedal' */
DW_pedal_T pedal_DW;

/*
 * Output and update for action system:
 *    '<S2>/Sensor1Fault'
 *    '<S2>/Sensor2Fault'
 */
void ASW_Sensor1Fault(real32_T rtu_In1, real32_T *rty_Out1)
{
  /* Saturate: '<S9>/Saturation' */
  if (rtu_In1 > 20.0F) {
    *rty_Out1 = 20.0F;
  } else if (rtu_In1 < 0.0F) {
    *rty_Out1 = 0.0F;
  } else {
    *rty_Out1 = rtu_In1;
  }

  /* End of Saturate: '<S9>/Saturation' */
}

/* Initial conditions for atomic system: '<Root>/pedal' */
void pedal_Init(void)
{
  /* InitializeConditions for Chart: '<S4>/StateMachine' */
  pedal_DW.is_active_c3_ASW = 0U;
  pedal_DW.is_c3_ASW = ASW_IN_NO_ACTIVE_CHILD;
}

/* Start for atomic system: '<Root>/pedal' */
void pedal_Start(void)
{
  /* Start for Merge: '<S2>/Merge' */
  pedalOut = 0.0F;
}

/* Output and update for atomic system: '<Root>/pedal' */
void pedal(uint16_T rtu_pedal1ADC, uint16_T rtu_pedal2ADC)
{
  /* local block i/o variables */
  real32_T rtb_Saturation;
  real32_T rtb_Saturation_c;
  real32_T rtb_Product_h;
  boolean_T rtb_LogicalOperator;
  real32_T rtb_Abs;
  boolean_T rtb_LogicalOperator_n;
  boolean_T rtb_RelationalOperator1_l;
  uint8_T rtb_state;
  uint16_T rtu_pedal1ADC_0;

  /* Saturate: '<S13>/Saturation' */
  if (rtu_pedal1ADC <= 4095) {
    rtu_pedal1ADC_0 = rtu_pedal1ADC;
  } else {
    rtu_pedal1ADC_0 = 4095U;
  }

  /* Product: '<S13>/Divide' incorporates:
   *  Saturate: '<S13>/Saturation'
   */
  rtb_Product_h = (real32_T)rtu_pedal1ADC_0 / 819.0F;

  /* Logic: '<S12>/Logical Operator' incorporates:
   *  Constant: '<S12>/Constant'
   *  Constant: '<S12>/Constant1'
   *  RelationalOperator: '<S12>/Relational Operator'
   *  RelationalOperator: '<S12>/Relational Operator1'
   */
  rtb_LogicalOperator = ((rtb_Product_h < 0.5F) || (rtb_Product_h > 4.5F));

  /* Saturate: '<S16>/Saturation' */
  if (rtu_pedal2ADC <= 4095) {
    rtu_pedal1ADC_0 = rtu_pedal2ADC;
  } else {
    rtu_pedal1ADC_0 = 4095U;
  }

  /* Product: '<S16>/Divide' incorporates:
   *  Saturate: '<S16>/Saturation'
   */
  rtb_Abs = (real32_T)rtu_pedal1ADC_0 / 819.0F;

  /* Logic: '<S15>/Logical Operator' incorporates:
   *  Constant: '<S15>/Constant'
   *  Constant: '<S15>/Constant1'
   *  RelationalOperator: '<S15>/Relational Operator'
   *  RelationalOperator: '<S15>/Relational Operator1'
   */
  rtb_LogicalOperator_n = ((rtb_Abs < 0.5F) || (rtb_Abs > 4.5F));

  /* Product: '<S14>/Product' incorporates:
   *  Constant: '<S14>/Constant'
   *  Constant: '<S14>/Constant1'
   *  Sum: '<S14>/Add'
   */
  rtb_Product_h = (rtb_Product_h - 0.5F) * 25.0F;

  /* Saturate: '<S14>/Saturation' */
  if (rtb_Product_h > 100.0F) {
    rtb_Saturation = 100.0F;
  } else if (rtb_Product_h < 0.0F) {
    rtb_Saturation = 0.0F;
  } else {
    rtb_Saturation = rtb_Product_h;
  }

  /* End of Saturate: '<S14>/Saturation' */

  /* Sum: '<S17>/Add1' incorporates:
   *  Constant: '<S17>/Constant'
   *  Constant: '<S17>/Constant1'
   *  Constant: '<S17>/Constant2'
   *  Product: '<S17>/Product'
   *  Sum: '<S17>/Add'
   */
  rtb_Product_h = 100.0F - (rtb_Abs - 0.5F) * 25.0F;

  /* Saturate: '<S17>/Saturation' */
  if (rtb_Product_h > 100.0F) {
    rtb_Saturation_c = 100.0F;
  } else if (rtb_Product_h < 0.0F) {
    rtb_Saturation_c = 0.0F;
  } else {
    rtb_Saturation_c = rtb_Product_h;
  }

  /* End of Saturate: '<S17>/Saturation' */

  /* RelationalOperator: '<S3>/Relational Operator1' incorporates:
   *  Abs: '<S3>/Abs'
   *  Constant: '<S3>/Constant1'
   *  Sum: '<S3>/Add'
   */
  rtb_RelationalOperator1_l = ((real32_T)fabs(rtb_Saturation - rtb_Saturation_c)
    > 0.5F);

  /* Chart: '<S4>/StateMachine' */
  /* Gateway: pedal/StateMachine/StateMachine */
  /* During: pedal/StateMachine/StateMachine */
  if (pedal_DW.is_active_c3_ASW == 0U) {
    /* Entry: pedal/StateMachine/StateMachine */
    pedal_DW.is_active_c3_ASW = 1U;

    /* Entry Internal: pedal/StateMachine/StateMachine */
    /* Transition: '<S11>:5' */
    pedal_DW.is_c3_ASW = ASW_IN_Running;

    /* Entry 'Running': '<S11>:1' */
    rtb_state = 0U;
  } else {
    switch (pedal_DW.is_c3_ASW) {
     case ASW_IN_COH:
      /* During 'COH': '<S11>:4' */
      /* Transition: '<S11>:17' */
      if (rtb_LogicalOperator && rtb_LogicalOperator_n) {
        /* Transition: '<S11>:8' */
        pedal_DW.is_c3_ASW = ASW_IN_COH;

        /* Entry 'COH': '<S11>:4' */
        rtb_state = 3U;
      } else if (rtb_LogicalOperator) {
        /* Transition: '<S11>:9' */
        pedal_DW.is_c3_ASW = ASW_IN_Sensor1Fault;

        /* Entry 'Sensor1Fault': '<S11>:2' */
        rtb_state = 1U;
      } else if (rtb_LogicalOperator_n) {
        /* Transition: '<S11>:10' */
        pedal_DW.is_c3_ASW = ASW_IN_Sensor2Fault;

        /* Entry 'Sensor2Fault': '<S11>:3' */
        rtb_state = 2U;
      } else if (rtb_RelationalOperator1_l) {
        /* Transition: '<S11>:11' */
        pedal_DW.is_c3_ASW = ASW_IN_COH;

        /* Entry 'COH': '<S11>:4' */
        rtb_state = 3U;
      } else {
        /* Transition: '<S11>:12' */
        pedal_DW.is_c3_ASW = ASW_IN_Running;

        /* Entry 'Running': '<S11>:1' */
        rtb_state = 0U;
      }
      break;

     case ASW_IN_Running:
      /* During 'Running': '<S11>:1' */
      /* Transition: '<S11>:7' */
      if (rtb_LogicalOperator && rtb_LogicalOperator_n) {
        /* Transition: '<S11>:8' */
        pedal_DW.is_c3_ASW = ASW_IN_COH;

        /* Entry 'COH': '<S11>:4' */
        rtb_state = 3U;
      } else if (rtb_LogicalOperator) {
        /* Transition: '<S11>:9' */
        pedal_DW.is_c3_ASW = ASW_IN_Sensor1Fault;

        /* Entry 'Sensor1Fault': '<S11>:2' */
        rtb_state = 1U;
      } else if (rtb_LogicalOperator_n) {
        /* Transition: '<S11>:10' */
        pedal_DW.is_c3_ASW = ASW_IN_Sensor2Fault;

        /* Entry 'Sensor2Fault': '<S11>:3' */
        rtb_state = 2U;
      } else if (rtb_RelationalOperator1_l) {
        /* Transition: '<S11>:11' */
        pedal_DW.is_c3_ASW = ASW_IN_COH;

        /* Entry 'COH': '<S11>:4' */
        rtb_state = 3U;
      } else {
        /* Transition: '<S11>:12' */
        pedal_DW.is_c3_ASW = ASW_IN_Running;

        /* Entry 'Running': '<S11>:1' */
        rtb_state = 0U;
      }
      break;

     case ASW_IN_Sensor1Fault:
      /* During 'Sensor1Fault': '<S11>:2' */
      /* Transition: '<S11>:13' */
      if (rtb_LogicalOperator && rtb_LogicalOperator_n) {
        /* Transition: '<S11>:8' */
        pedal_DW.is_c3_ASW = ASW_IN_COH;

        /* Entry 'COH': '<S11>:4' */
        rtb_state = 3U;
      } else if (rtb_LogicalOperator) {
        /* Transition: '<S11>:9' */
        pedal_DW.is_c3_ASW = ASW_IN_Sensor1Fault;

        /* Entry 'Sensor1Fault': '<S11>:2' */
        rtb_state = 1U;
      } else if (rtb_LogicalOperator_n) {
        /* Transition: '<S11>:10' */
        pedal_DW.is_c3_ASW = ASW_IN_Sensor2Fault;

        /* Entry 'Sensor2Fault': '<S11>:3' */
        rtb_state = 2U;
      } else if (rtb_RelationalOperator1_l) {
        /* Transition: '<S11>:11' */
        pedal_DW.is_c3_ASW = ASW_IN_COH;

        /* Entry 'COH': '<S11>:4' */
        rtb_state = 3U;
      } else {
        /* Transition: '<S11>:12' */
        pedal_DW.is_c3_ASW = ASW_IN_Running;

        /* Entry 'Running': '<S11>:1' */
        rtb_state = 0U;
      }
      break;

     default:
      /* During 'Sensor2Fault': '<S11>:3' */
      /* Transition: '<S11>:14' */
      if (rtb_LogicalOperator && rtb_LogicalOperator_n) {
        /* Transition: '<S11>:8' */
        pedal_DW.is_c3_ASW = ASW_IN_COH;

        /* Entry 'COH': '<S11>:4' */
        rtb_state = 3U;
      } else if (rtb_LogicalOperator) {
        /* Transition: '<S11>:9' */
        pedal_DW.is_c3_ASW = ASW_IN_Sensor1Fault;

        /* Entry 'Sensor1Fault': '<S11>:2' */
        rtb_state = 1U;
      } else if (rtb_LogicalOperator_n) {
        /* Transition: '<S11>:10' */
        pedal_DW.is_c3_ASW = ASW_IN_Sensor2Fault;

        /* Entry 'Sensor2Fault': '<S11>:3' */
        rtb_state = 2U;
      } else if (rtb_RelationalOperator1_l) {
        /* Transition: '<S11>:11' */
        pedal_DW.is_c3_ASW = ASW_IN_COH;

        /* Entry 'COH': '<S11>:4' */
        rtb_state = 3U;
      } else {
        /* Transition: '<S11>:12' */
        pedal_DW.is_c3_ASW = ASW_IN_Running;

        /* Entry 'Running': '<S11>:1' */
        rtb_state = 0U;
      }
      break;
    }
  }

  /* End of Chart: '<S4>/StateMachine' */

  /* SwitchCase: '<S2>/Switch Case' incorporates:
   *  Inport: '<S8>/In1'
   */
  switch (rtb_state) {
   case 0:
    /* Outputs for IfAction SubSystem: '<S2>/Running' incorporates:
     *  ActionPort: '<S8>/Action Port'
     */
    pedalOut = rtb_Saturation;

    /* End of Outputs for SubSystem: '<S2>/Running' */
    break;

   case 1:
    /* Outputs for IfAction SubSystem: '<S2>/Sensor1Fault' incorporates:
     *  ActionPort: '<S9>/Action Port'
     */
    ASW_Sensor1Fault(rtb_Saturation_c, (&(pedalOut)));

    /* End of Outputs for SubSystem: '<S2>/Sensor1Fault' */
    break;

   case 2:
    /* Outputs for IfAction SubSystem: '<S2>/Sensor2Fault' incorporates:
     *  ActionPort: '<S10>/Action Port'
     */
    ASW_Sensor1Fault(rtb_Saturation, (&(pedalOut)));

    /* End of Outputs for SubSystem: '<S2>/Sensor2Fault' */
    break;

   case 3:
    /* Outputs for IfAction SubSystem: '<S2>/Cho' incorporates:
     *  ActionPort: '<S7>/Action Port'
     */
    /* SignalConversion: '<S7>/OutportBufferForOut1' incorporates:
     *  Constant: '<S7>/Constant1'
     */
    pedalOut = 0.0F;

    /* End of Outputs for SubSystem: '<S2>/Cho' */
    break;
  }

  /* End of SwitchCase: '<S2>/Switch Case' */
}

/* Initialize for atomic system: '<Root>/pedal' */
void pedal_initialize(void)
{
  /* custom signals */
  pedalOut = 0.0F;
  (void) memset((void *)&pedal_DW, 0,
                sizeof(DW_pedal_T));
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
