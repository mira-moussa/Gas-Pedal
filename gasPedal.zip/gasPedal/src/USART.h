/*
 * USART.c
 *
 *  Created on: Nov 27, 2019
 *      Author: Mohamed Samy
 */

#ifndef USART_H_
#define USART_H_

#include "stm32f10x_usart.h"

void USART_init(void);
void USART_sendStr(uint8_t *Buffer);
void USART_sendInt(uint16_t Buffer);

#endif /* USART_H_ */
