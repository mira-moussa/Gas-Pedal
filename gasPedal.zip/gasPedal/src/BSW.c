/*
 * BSW.c
 *
 *  Created on: Nov 27, 2019
 *      Author: Mohamed Samy
 */

#include "BSW.h"

void DIO_initialize();

//volatile uint8_t idleCntr = 0;
//volatile uint8_t encoderCntr = 0;
volatile uint16_t ADCVal1 = 0;
volatile uint16_t ADCVal2 = 0;

void BSW_init()
{
	DIO_initialize();
	ADC_init();
	//USART_init();
	Timer_init();
}

void DIO_initialize()
{
	DIO_INIT(A0, pinMode_Out_PP);
}

void ADC1_2_IRQHandler()
{
    //if(ADC_GetFlagStatus(ADC1, ADC_FLAG_AWD) != RESET){
    	ADCVal1 = ADC_Read(0);
    	ADCVal2 = ADC_Read(1);
		Task_100us();
    //}
}

void TIM2_IRQHandler()
{
	if (TIM_GetITStatus(TIM2, TIM_IT_Update) != RESET)
	{
		TIM_ClearITPendingBit(TIM2, TIM_IT_Update);
		ADC_StartConv();
	}
}
